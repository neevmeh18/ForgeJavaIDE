"""Tiny console helpers: colored status lines and interactive prompts.

Color is off when ``NO_COLOR`` is set, or when neither stdout nor stderr is a TTY
(CI, pipes). ``FORCE_COLOR`` turns it back on. Git hooks often pipe stdout while
stderr is still a terminal — we color in that case too.
"""

import getpass
import itertools
import os
import sys
import threading
import time
from collections.abc import Iterator
from contextlib import contextmanager

_COLORS = {
    "green": "\033[32m",
    "yellow": "\033[33m",
    "red": "\033[31m",
    "cyan": "\033[36m",
    "dim": "\033[2m",
    "bold": "\033[1m",
    "underline": "\033[4m",
}
_RESET = "\033[0m"
_FORCE_COLOR = frozenset({"1", "true", "yes", "on"})


def _use_color() -> bool:
    """Color when the user can see it: a TTY, or FORCE_COLOR.

    Git hooks often pipe stdout; stderr may still be a TTY. ``NO_COLOR`` always wins.
    """
    if "NO_COLOR" in os.environ:
        return False
    if os.environ.get("FORCE_COLOR", "").strip().lower() in _FORCE_COLOR:
        return True
    return sys.stdout.isatty() or sys.stderr.isatty()


def _paint(text: str, *styles: str) -> str:
    if not _use_color() or not styles:
        return text
    prefix = "".join(_COLORS[style] for style in styles)
    return f"{prefix}{text}{_RESET}"


def success(message: str) -> None:
    print(f"{_paint('✓', 'green')} {message}")


def warn(message: str) -> None:
    print(f"{_paint('!', 'yellow')} {message}")


def error(message: str) -> None:
    print(f"{_paint('✗', 'red')} {message}", file=sys.stderr)


def info(message: str) -> None:
    print(message)


def hint(message: str) -> None:
    print(_paint(message, "dim"))


def muted(text: str) -> str:
    return _paint(text, "dim")


def heading(message: str) -> None:
    print(f"\n{_paint(message, 'cyan')}")


def hyperlink(url: str) -> str:
    """Bold underlined cyan URL, wrapped in OSC-8 so supporting terminals make it clickable."""
    painted = _paint(url, "bold", "underline", "cyan")
    if not _use_color():
        return url
    return f"\033]8;;{url}\033\\{painted}\033]8;;\033\\"


def severity(name: str, count: int) -> str:
    color = {"critical": "red", "high": "red", "medium": "yellow", "low": "dim"}.get(name, "dim")
    if count <= 0:
        return _paint(f"{name} {count}", "dim")
    return _paint(f"{name} {count}", color)


_SPINNER_FRAMES = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"


@contextmanager
def spinner(message: str) -> Iterator[None]:
    """Animate ``message`` on stderr while the wrapped block runs.

    The animation only kicks in on an interactive stderr; when stderr is redirected
    or piped (CI, ``2>&1 | cat``) it degrades to a single static line so logs stay
    clean. The cursor is always restored and the line cleared on exit, even if the
    block raises.
    """
    if not (sys.stderr.isatty() and "NO_COLOR" not in os.environ):
        print(f"{message}…", file=sys.stderr)
        yield
        return

    done = threading.Event()

    def _spin() -> None:
        sys.stderr.write("\033[?25l")  # hide the cursor while spinning
        for frame in itertools.cycle(_SPINNER_FRAMES):
            if done.is_set():
                break
            sys.stderr.write(f"\r{_paint(frame, 'cyan')} {message}…")
            sys.stderr.flush()
            time.sleep(0.08)

    thread = threading.Thread(target=_spin, daemon=True)
    thread.start()
    try:
        yield
    finally:
        done.set()
        thread.join()
        sys.stderr.write("\r\033[2K\033[?25h")  # clear the line, restore the cursor
        sys.stderr.flush()


def prompt(label: str, default: str | None = None) -> str:
    suffix = f" [{default}]" if default else ""
    answer = input(f"{label}{suffix}: ").strip()
    return answer or (default or "")


def secret(label: str) -> str:
    return getpass.getpass(f"{label}: ").strip()


def confirm(question: str, default: bool = True) -> bool:
    choices = "Y/n" if default else "y/N"
    answer = input(f"{question} [{choices}]: ").strip().lower()
    if not answer:
        return default
    return answer in {"y", "yes"}


__all__ = [
    "confirm",
    "error",
    "heading",
    "hint",
    "hyperlink",
    "info",
    "muted",
    "prompt",
    "secret",
    "severity",
    "spinner",
    "success",
    "warn",
]
