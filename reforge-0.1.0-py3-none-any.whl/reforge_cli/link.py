"""The per-folder project link (`.reforge/project.toml`).

`reforge init` writes this file at the repository root to bind the checkout to a
dashboard project. It holds only the project identifier (``owner/name``) — never a
secret — so it is safe to commit or gitignore. `reforge scan` and the MCP server
read it (searching upward from the working directory, like git does) to know which
project a checkout belongs to.
"""

import tomllib
from dataclasses import dataclass
from pathlib import Path

LINK_DIR = ".reforge"
LINK_FILE = "project.toml"


class LinkError(ValueError):
    """The project link file is present but malformed."""


@dataclass(frozen=True)
class ProjectLink:
    project: str
    api_base: str | None = None


def _link_path(root: Path) -> Path:
    return root / LINK_DIR / LINK_FILE


def find_link_path(start: Path | None = None) -> Path | None:
    """Search from ``start`` (default cwd) up to the filesystem root for a link file."""
    current = (start or Path.cwd()).resolve()
    for directory in [current, *current.parents]:
        candidate = _link_path(directory)
        if candidate.is_file():
            return candidate
    return None


def load_link(start: Path | None = None) -> ProjectLink | None:
    path = find_link_path(start)
    if path is None:
        return None
    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError) as exc:
        raise LinkError(f"Could not read the ReForge link file at {path}: {exc}") from exc
    project = data.get("project")
    if not isinstance(project, str) or not project.strip():
        raise LinkError(f"The ReForge link file at {path} has no 'project' value.")
    api_base = data.get("api_base")
    return ProjectLink(
        project=project.strip(),
        api_base=api_base.strip() if isinstance(api_base, str) and api_base.strip() else None,
    )


def write_link(root: Path, link: ProjectLink) -> Path:
    """Write ``<root>/.reforge/project.toml`` and return its path."""
    path = _link_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "# ReForge project link — created by `reforge init`. Safe to commit.",
        f'project = "{link.project}"',
    ]
    if link.api_base:
        lines.append(f'api_base = "{link.api_base}"')
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


__all__ = ["LinkError", "ProjectLink", "find_link_path", "load_link", "write_link"]
