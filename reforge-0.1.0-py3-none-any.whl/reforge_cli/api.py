"""Typed wrappers over the ReForge product API endpoints the CLI uses."""

from typing import Any

from reforge_cli.config import ClientConfig
from reforge_cli.http import get_json


def whoami(config: ClientConfig) -> dict[str, Any]:
    """GET /v1/me — verify the API key and return {user, team}."""
    body = get_json(config, "/v1/me")
    return body if isinstance(body, dict) else {}


def list_projects(config: ClientConfig) -> list[dict[str, Any]]:
    """GET /v1/projects — the team's registered projects."""
    body = get_json(config, "/v1/projects")
    return [p for p in body if isinstance(p, dict)] if isinstance(body, list) else []


__all__ = ["list_projects", "whoami"]
