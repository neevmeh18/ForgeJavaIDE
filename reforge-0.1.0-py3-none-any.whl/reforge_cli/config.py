"""Global, per-user client configuration (`~/.config/reforge/config.env`).

Holds the API key and API base URL shared by every ReForge command. Environment
variables take precedence over the file. The file lives outside any repository so
the credential can't be committed by accident, and it must be private (mode 0600).
"""

import os
import stat
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path

DEFAULT_API_BASE_URL = "http://127.0.0.1:8787"
_SUPPORTED_KEYS = {"REFORGE_API_KEY", "REFORGE_API_BASE_URL"}


class ClientConfigError(ValueError):
    """The local ReForge client configuration is missing or unsafe."""


@dataclass(frozen=True)
class ClientConfig:
    api_key: str
    api_base_url: str


def config_path(environ: Mapping[str, str] | None = None) -> Path:
    env = os.environ if environ is None else environ
    if xdg_home := env.get("XDG_CONFIG_HOME"):
        return Path(xdg_home).expanduser() / "reforge" / "config.env"
    home = Path(env.get("HOME", str(Path.home()))).expanduser()
    return home / ".config" / "reforge" / "config.env"


def _read_config_file(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}
    if not path.is_file():
        raise ClientConfigError(f"ReForge config path is not a file: {path}")
    if stat.S_IMODE(path.stat().st_mode) & 0o077:
        raise ClientConfigError(f"ReForge config must be private. Run: chmod 600 {path}")

    values: dict[str, str] = {}
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise ClientConfigError(f"Could not read ReForge config: {path}") from exc
    for number, raw_line in enumerate(lines, start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            raise ClientConfigError(f"Invalid ReForge config line {number} in {path}")
        key, value = line.split("=", 1)
        key = key.strip()
        if key not in _SUPPORTED_KEYS:
            raise ClientConfigError(f"Unsupported ReForge config key {key!r} in {path}")
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
            value = value[1:-1]
        values[key] = value
    return values


def normalize_api_base_url(value: str) -> str:
    base = value.strip().rstrip("/")
    if not base.startswith(("http://", "https://")):
        raise ClientConfigError("REFORGE_API_BASE_URL must start with http:// or https://")
    return base


def load_client_config(environ: Mapping[str, str] | None = None) -> ClientConfig:
    env = os.environ if environ is None else environ
    file_values = _read_config_file(config_path(env))
    api_key = env.get("REFORGE_API_KEY") or file_values.get("REFORGE_API_KEY")
    if not api_key:
        raise ClientConfigError(
            "No REFORGE_API_KEY configured. Run `reforge login`, or add it to "
            "~/.config/reforge/config.env and run chmod 600 on that file."
        )
    api_base_url = (
        env.get("REFORGE_API_BASE_URL")
        or file_values.get("REFORGE_API_BASE_URL")
        or DEFAULT_API_BASE_URL
    )
    return ClientConfig(api_key=api_key, api_base_url=normalize_api_base_url(api_base_url))


def save_client_config(config: ClientConfig, environ: Mapping[str, str] | None = None) -> Path:
    """Persist the API key and base URL to the private per-user config file.

    Creates the directory (0700) and file (0600) so the credential is never
    world-readable. Called by `reforge login`.
    """
    path = config_path(environ)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.parent.chmod(0o700)
    body = (
        "# ReForge client configuration — created by `reforge login`.\n"
        f"REFORGE_API_KEY={config.api_key}\n"
        f"REFORGE_API_BASE_URL={config.api_base_url}\n"
    )
    # Create with 0600 from the start so the key is never briefly world-readable.
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        handle.write(body)
    path.chmod(0o600)
    return path
