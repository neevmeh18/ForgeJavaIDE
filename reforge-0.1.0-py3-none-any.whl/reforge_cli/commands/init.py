"""`reforge init` — link this checkout to a dashboard project and wire up tooling.

One guided command: verify the API key, confirm the repository, match it to a
registered project, write the ``.reforge/project.toml`` link, then optionally
install the pre-commit hook and write the Claude/Codex MCP config.
"""

import argparse
from pathlib import Path
from typing import Any

from reforge_cli import ui
from reforge_cli.agent_config import write_claude_config, write_codex_config
from reforge_cli.api import list_projects
from reforge_cli.commands.login import ensure_login
from reforge_cli.config import ClientConfig, ClientConfigError
from reforge_cli.git_remote import detect_local_repo, git_toplevel, normalize_repo_full_name
from reforge_cli.hook import install_precommit_hook
from reforge_cli.http import ClientRequestError
from reforge_cli.link import ProjectLink, write_link


def _match_project(projects: list[dict[str, Any]], identifier: str) -> dict[str, Any] | None:
    """Find the project whose repo_full_name (or slug) matches the identifier."""
    normalized = normalize_repo_full_name(identifier) or identifier.strip().lower()
    for project in projects:
        repo = (project.get("repo_full_name") or "").lower()
        if repo and repo == normalized:
            return project
        if project.get("slug", "").lower() == identifier.strip().lower():
            return project
    return None


def _choose_identifier(args: argparse.Namespace, root: Path) -> str:
    if args.project:
        return args.project
    detected = detect_local_repo(str(root))
    if args.yes:
        if not detected:
            raise ClientConfigError(
                "Could not detect a Git remote. Re-run with --project owner/name."
            )
        return detected
    return ui.prompt("Project (owner/name)", default=detected or None) or (detected or "")


def _verify(config: ClientConfig, identifier: str) -> dict[str, Any]:
    projects = list_projects(config)
    match = _match_project(projects, identifier)
    if match is not None:
        return match
    ui.error(f"No ReForge project matches '{identifier}'.")
    if projects:
        available = ", ".join(sorted(p.get("repo_full_name", p.get("slug", "?")) for p in projects))
        ui.hint(f"Projects on your team: {available}")
    ui.hint("Add this repository on the ReForge dashboard, then re-run `reforge init`.")
    raise SystemExit(1)


def _install_hook(root: Path) -> None:
    result = install_precommit_hook(root)
    (ui.success if result.ok else ui.warn)(result.message)


def _write_agent_configs(root: Path, project: str, agents: set[str]) -> None:
    if "claude" in agents:
        result = write_claude_config(root, project)
        (ui.warn if result.outcome.value == "skipped" else ui.success)(result.message)
    if "codex" in agents:
        result = write_codex_config(root, project)
        (ui.warn if result.outcome.value == "skipped" else ui.success)(result.message)


def _selected_agents(args: argparse.Namespace) -> set[str]:
    if args.no_mcp:
        return set()
    if args.agent:
        return {"claude", "codex"} if args.agent == "both" else {args.agent}
    if args.yes:
        return {"claude", "codex"}
    agents: set[str] = set()
    if ui.confirm("Write the Claude Code MCP config (.mcp.json)?"):
        agents.add("claude")
    if ui.confirm("Write the Codex MCP config (.codex/config.toml)?"):
        agents.add("codex")
    return agents


def run(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="reforge init", description="Link this repo to ReForge.")
    parser.add_argument("--project", default=None, help="Project owner/name (skips detection).")
    parser.add_argument("--yes", "-y", action="store_true", help="Accept all prompts.")
    parser.add_argument("--no-hook", action="store_true", help="Skip the pre-commit hook.")
    parser.add_argument("--no-mcp", action="store_true", help="Skip writing agent MCP config.")
    parser.add_argument("--agent", choices=["claude", "codex", "both"], default=None)
    args = parser.parse_args(argv)

    root_path = git_toplevel()
    if root_path is None:
        ui.error("Run `reforge init` from inside a Git repository.")
        return 1
    root = Path(root_path)

    try:
        config = ensure_login(assume_yes=args.yes)
        identifier = _choose_identifier(args, root)
        if not identifier:
            ui.error("A project identifier is required.")
            return 1
        project = _verify(config, identifier)
    except (ClientConfigError, ClientRequestError) as exc:
        ui.error(str(exc))
        return 1

    repo_full_name = project.get("repo_full_name") or identifier
    link_path = write_link(root, ProjectLink(project=repo_full_name))
    ui.success(f"Linked to '{project.get('name', repo_full_name)}' ({repo_full_name})")
    ui.hint(f"Wrote {link_path}")

    if not args.no_hook and (args.yes or ui.confirm("Install the pre-commit hook?")):
        _install_hook(root)
    _write_agent_configs(root, repo_full_name, _selected_agents(args))

    ui.heading("Done. Next steps:")
    ui.hint("• Restart your coding agent so it picks up the MCP server.")
    ui.hint("• Stage a change and commit to see a scan report in .reforge/findings/.")
    ui.hint("• Run `reforge status` any time to check this setup.")
    return 0


__all__ = ["run"]
