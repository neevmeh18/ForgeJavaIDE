"""`reforge status` — show the resolved setup for the current checkout."""

import argparse
from pathlib import Path

from reforge_cli import ui
from reforge_cli.agent_config import claude_config_present, codex_config_present
from reforge_cli.api import list_projects, whoami
from reforge_cli.config import ClientConfigError, load_client_config
from reforge_cli.git_remote import detect_local_repo, git_toplevel
from reforge_cli.hook import hook_installed
from reforge_cli.http import ClientRequestError
from reforge_cli.link import LinkError, load_link


def _report_account() -> None:
    try:
        config = load_client_config()
    except ClientConfigError as exc:
        ui.warn(f"No API key: {exc}")
        return
    ui.info(f"  API base : {config.api_base_url}")
    try:
        identity = whoami(config)
        user = identity.get("user", {})
        team = identity.get("team", {})
        ui.success(f"  Signed in: {user.get('full_name', '?')} · team {team.get('name', '?')}")
    except (ClientRequestError, ClientConfigError) as exc:
        ui.error(f"  Key rejected: {exc}")


def _report_project() -> None:
    try:
        link = load_link()
    except LinkError as exc:
        ui.error(f"  Link file: {exc}")
        return
    detected = detect_local_repo()
    ui.info(f"  Git remote: {detected or 'none'}")
    if link is None:
        ui.warn("  Not linked. Run `reforge init` to link this repository.")
        return
    ui.info(f"  Linked to : {link.project}")
    target = link.project.lower()
    try:
        projects = list_projects(load_client_config())
    except (ClientRequestError, ClientConfigError):
        ui.hint("  Backend   : skipped (no working API key)")
        return
    matched = any((p.get("repo_full_name") or "").lower() == target for p in projects)
    if matched:
        ui.success("  Backend   : project found")
    else:
        ui.warn("  Backend   : no matching project (add it on the dashboard)")


def _line(present: bool, label: str) -> None:
    (ui.success if present else ui.hint)(f"  {label}: {'present' if present else 'absent'}")


def _report_tooling(root: Path) -> None:
    if hook_installed(root):
        ui.success("  Pre-commit hook: installed")
    else:
        ui.warn("  Pre-commit hook: not installed")
    _line(claude_config_present(root), "Claude .mcp.json")
    _line(codex_config_present(root), "Codex config")


def run(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="reforge status", description="Show ReForge setup.")
    parser.parse_args(argv)

    ui.heading("Account")
    _report_account()

    ui.heading("Project")
    _report_project()

    root = git_toplevel()
    if root:
        ui.heading("Tooling")
        _report_tooling(Path(root))
    return 0


__all__ = ["run"]
