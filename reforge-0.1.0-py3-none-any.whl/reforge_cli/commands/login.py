"""`reforge login` — store and verify the per-user API key.

Writes the key and API base URL to ``~/.config/reforge/config.env`` (0600) after
confirming they work against ``GET /v1/me``. `reforge init` reuses ``ensure_login``
so a first-time developer is prompted for a key inline.
"""

import argparse

from reforge_cli import ui
from reforge_cli.api import whoami
from reforge_cli.config import (
    DEFAULT_API_BASE_URL,
    ClientConfig,
    ClientConfigError,
    load_client_config,
    normalize_api_base_url,
    save_client_config,
)
from reforge_cli.http import ClientRequestError


def _existing_base_url() -> str:
    try:
        return load_client_config().api_base_url
    except ClientConfigError:
        return DEFAULT_API_BASE_URL


def _describe(identity: dict) -> str:
    user = identity.get("user", {})
    team = identity.get("team", {})
    name = user.get("full_name") or user.get("email") or "your account"
    role = user.get("role")
    role_suffix = f" ({role})" if role else ""
    return f"Signed in as {name}{role_suffix} · team {team.get('name', '?')}"


def resolve_and_verify(api_key: str, api_base_url: str) -> tuple[ClientConfig, dict]:
    """Build a config, confirm it against the API, and return (config, identity)."""
    config = ClientConfig(api_key=api_key, api_base_url=normalize_api_base_url(api_base_url))
    identity = whoami(config)
    return config, identity


def ensure_login(*, assume_yes: bool = False) -> ClientConfig:
    """Return a working config, prompting for a key if none is configured.

    Raises ``ClientConfigError`` when non-interactive and no key is available.
    """
    try:
        config = load_client_config()
        whoami(config)  # cheap check that the stored key still works
        return config
    except ClientConfigError:
        if assume_yes:
            raise
        ui.warn("No ReForge API key configured yet.")
        return _interactive_login(default_base=DEFAULT_API_BASE_URL)


def _interactive_login(default_base: str) -> ClientConfig:
    api_key = ui.secret("API key (from your dashboard — reveal once)")
    if not api_key:
        raise ClientConfigError("An API key is required.")
    api_base = ui.prompt("API base URL", default=default_base)
    config, identity = resolve_and_verify(api_key, api_base)
    path = save_client_config(config)
    ui.success(_describe(identity))
    ui.hint(f"Saved to {path}")
    return config


def run(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="reforge login", description="Store your API key.")
    parser.add_argument("--api-key", default=None, help="API key (otherwise prompted).")
    parser.add_argument("--api-base", default=None, help="ReForge API base URL.")
    parser.add_argument("--yes", "-y", action="store_true", help="Non-interactive.")
    args = parser.parse_args(argv)

    api_base = args.api_base or _existing_base_url()
    api_key = args.api_key
    if not api_key:
        if args.yes:
            ui.error("--yes requires --api-key.")
            return 2
        return 0 if _try_interactive(api_base) else 1

    try:
        config, identity = resolve_and_verify(api_key, api_base)
    except (ClientConfigError, ClientRequestError) as exc:
        ui.error(str(exc))
        return 1
    path = save_client_config(config)
    ui.success(_describe(identity))
    ui.hint(f"Saved to {path}")
    return 0


def _try_interactive(default_base: str) -> bool:
    try:
        _interactive_login(default_base)
        return True
    except (ClientConfigError, ClientRequestError) as exc:
        ui.error(str(exc))
        return False


__all__ = ["ensure_login", "resolve_and_verify", "run"]
