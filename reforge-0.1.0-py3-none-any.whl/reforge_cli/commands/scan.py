"""`reforge scan` — the pre-commit security scan.

Sends a staged unified diff to ``/v1/precommit/scan``, writes
``.reforge/findings/<scan>.md``, and prints a summary. A completed scan blocks
only when the repository's policy is reached.

The project is resolved from ``--project``/``--repo``, then the checkout's
``.reforge/project.toml`` link, then the Git remote. Client configuration is read
from the environment or ``~/.config/reforge/config.env`` (`reforge login`).
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from dataclasses import replace
from pathlib import Path
from typing import Any

from reforge_cli import ui
from reforge_cli.config import (
    ClientConfigError,
    load_client_config,
    normalize_api_base_url,
)
from reforge_cli.git_remote import detect_local_repo
from reforge_cli.http import CREDIT_BLOCK_CODES, ClientRequestError, post_json
from reforge_cli.link import LinkError, load_link

_DEFAULT_TIMEOUT = 1100.0


def _git(*args: str) -> str:
    return subprocess.run(["git", *args], capture_output=True, text=True, check=True).stdout.strip()


def _staged_diff() -> str:
    """Unified staged diff for the agentic engine.

    ``-M`` plus ``ACMR`` so a rename is a rename hunk, not a full-file add.
    ``-U6`` gives surrounding control-flow without dumping whole files.
    """
    return _git(
        "diff",
        "--cached",
        "--no-color",
        "--no-ext-diff",
        "-M",
        "--diff-filter=ACMR",
        "-U6",
    )


def _current_branch() -> str:
    try:
        return _git("rev-parse", "--abbrev-ref", "HEAD")
    except subprocess.CalledProcessError:
        return "main"


def _resolve_target(
    project: str | None, repo: str | None
) -> tuple[dict[str, str] | None, str | None]:
    """Return (payload target, api_base override). Explicit args win, then the link
    file, then the local Git remote."""
    if project:
        return {"project": project}, None
    if repo:
        return {"repo": repo}, None
    try:
        link = load_link()
    except LinkError:
        link = None
    if link:
        return {"repo": link.project}, link.api_base
    detected = detect_local_repo()
    if detected:
        return {"repo": detected}, None
    return None, None


def _timeout(flag: float | None) -> float:
    if flag is not None:
        return flag
    raw = os.environ.get("REFORGE_SCAN_TIMEOUT")
    if raw:
        try:
            return float(raw)
        except ValueError:
            print(
                f"reforge: invalid REFORGE_SCAN_TIMEOUT={raw!r}; using {_DEFAULT_TIMEOUT}.",
                file=sys.stderr,
            )
    return _DEFAULT_TIMEOUT


def _counts_from_findings(findings: object) -> dict[str, int]:
    counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    if not isinstance(findings, list):
        return counts
    for item in findings:
        if not isinstance(item, dict):
            continue
        severity = item.get("severity")
        if severity in counts:
            counts[severity] += 1
    return counts


def _write_report(scan_id: object, report: str) -> Path:
    report_dir = Path(".reforge/findings")
    report_dir.mkdir(parents=True, exist_ok=True)
    report_path = report_dir / f"{scan_id}.md"
    report_path.write_text(report, encoding="utf-8")
    return report_path


def _print_summary(
    counts: dict[str, int], report_path: Path, scan_url: str, blocked: bool
) -> None:
    total = sum(counts.values())
    breakdown = "  ".join(
        ui.severity(name, counts[name]) for name in ("critical", "high", "medium", "low")
    )
    if blocked:
        ui.error(f"commit blocked · {total} finding(s)")
    elif total:
        ui.warn(f"{total} finding(s)")
    else:
        ui.success("no findings")
    print(f"  {breakdown}")
    print(f"  {ui.muted('report')}  {report_path}")
    print(f"  {ui.muted('view')}    {ui.hyperlink(scan_url)}")
    if blocked:
        ui.error("commit blocked by the repository's scan policy.")


def _print_scan_error(exc: ClientRequestError) -> None:
    # A plan/credit block is a real denial, not a scanner failure; the hook still
    # fails open (returns 0) so a billing issue never blocks a developer's commit.
    if getattr(exc, "code", None) in CREDIT_BLOCK_CODES:
        print(f"reforge: scan skipped — {exc}", file=sys.stderr)
    else:
        print(f"reforge: scan request failed: {exc}", file=sys.stderr)


def _run_agentic(config: Any, target: dict[str, str], branch: str, timeout: float) -> int:
    diff = _staged_diff()
    if not diff:
        print("reforge: no staged files to scan.")
        return 0
    payload = {**target, "branch": branch, "diff": diff}
    try:
        with ui.spinner("Running ReForge scan"):
            result = post_json(config, "/v1/precommit/scan?output=json", payload, timeout=timeout)
    except ClientRequestError as exc:
        _print_scan_error(exc)
        return 0
    try:
        scan = result["scan"]
        report_path = _write_report(scan["id"], result["report"])
        counts = _counts_from_findings(result["findings"])
        scan_url = result["scan_url"]
        blocked = bool(result["blocked"])
    except (KeyError, OSError, TypeError):
        print("reforge: scan returned an invalid response.", file=sys.stderr)
        return 0
    _print_summary(counts, report_path, scan_url, blocked)
    return 1 if blocked else 0


def _run(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="reforge scan", description="ReForge pre-commit scan.")
    parser.add_argument("--project", default=None, help="Project slug (overrides link/remote).")
    parser.add_argument("--repo", default=None, help="Repository owner/name (overrides link).")
    parser.add_argument("--branch", default=None)
    parser.add_argument("--api", default=None, help="Override the configured API URL.")
    parser.add_argument(
        "--timeout",
        type=float,
        default=None,
        help=f"HTTP timeout in seconds (default {_DEFAULT_TIMEOUT:.0f}, or REFORGE_SCAN_TIMEOUT).",
    )
    args = parser.parse_args(argv)

    try:
        config = load_client_config()
    except ClientConfigError as exc:
        print(f"reforge: {exc}", file=sys.stderr)
        return 0

    target, link_api_base = _resolve_target(args.project, args.repo)
    if target is None:
        print(
            "reforge: could not identify a project. Run `reforge init` in this repository, "
            "or pass --repo owner/name / --project slug.",
            file=sys.stderr,
        )
        return 0

    override = args.api or link_api_base
    if override:
        config = replace(config, api_base_url=normalize_api_base_url(override))

    branch = args.branch or _current_branch()
    return _run_agentic(config, target, branch, _timeout(args.timeout))


def run(argv: list[str] | None = None) -> int:
    """Run a scan; only a completed policy breach returns a blocking exit code."""
    try:
        return _run(argv)
    except SystemExit:
        raise
    except Exception:
        print("reforge: unexpected scanner error; commit will continue.", file=sys.stderr)
        return 0


if __name__ == "__main__":
    run()
