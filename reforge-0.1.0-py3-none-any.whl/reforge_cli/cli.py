"""The `reforge` command dispatcher.

Each subcommand owns its own argument parsing, so the dispatcher just routes the
first token and forwards the rest. New subcommands register in ``_COMMANDS``.
"""

import sys
from collections.abc import Callable

from reforge_cli.commands import init, login, scan, status
from reforge_cli.mcp import run as run_mcp

_COMMANDS: dict[str, Callable[[list[str]], int]] = {
    "login": login.run,
    "init": init.run,
    "scan": scan.run,
    "status": status.run,
    "mcp": lambda _argv: (run_mcp(), 0)[1],
}

_USAGE = """reforge — developer CLI for ReForge

Usage: reforge <command> [options]

Commands:
  login    Store and verify your API key
  init     Link this repository to a project and set up tooling
  scan     Run the pre-commit security scan
  status   Show the resolved setup for this checkout
  mcp      Run the stdio MCP server (usually launched by your coding agent)

Run `reforge <command> --help` for command-specific options."""


def run(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if not args or args[0] in {"-h", "--help", "help"}:
        print(_USAGE)
        return 0
    command, rest = args[0], args[1:]
    handler = _COMMANDS.get(command)
    if handler is None:
        print(f"reforge: unknown command '{command}'.\n\n{_USAGE}", file=sys.stderr)
        return 2
    return handler(rest)


if __name__ == "__main__":
    raise SystemExit(run())
