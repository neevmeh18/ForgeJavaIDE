"""Normalize a git remote / GitHub URL to a canonical ``owner/name``.

The CLI only knows the local git remote, so we reduce every form of GitHub URL to
one lowercase ``owner/name`` string and match that against a project's stored
``repo_full_name``. Handles:

    git@github.com:Owner/Repo.git
    https://github.com/Owner/Repo.git
    https://github.com/Owner/Repo
    ssh://git@github.com/Owner/Repo.git
    Owner/Repo

This is an intentional, dependency-free copy of the backend helper so the CLI stays
an independently installable package.
"""

import re
import subprocess

_TRAILING_GIT = re.compile(r"\.git$", re.IGNORECASE)


def normalize_repo_full_name(value: str) -> str | None:
    """Return the canonical ``owner/name`` (lowercased) or ``None`` if unparseable."""
    if not value:
        return None
    text = _TRAILING_GIT.sub("", value.strip())

    # scp-style: git@host:owner/name
    if "@" in text and ":" in text and "://" not in text:
        text = text.split(":", 1)[1]
    elif "://" in text:
        # scheme://[user@]host/owner/name  -> drop scheme+host
        after_scheme = text.split("://", 1)[1]
        text = after_scheme.split("/", 1)[1] if "/" in after_scheme else ""

    parts = [p for p in text.strip("/").split("/") if p]
    if len(parts) < 2:
        return None
    owner, name = parts[-2], parts[-1]
    if not owner or not name:
        return None
    return f"{owner}/{name}".lower()


def detect_local_repo(cwd: str | None = None) -> str | None:
    """Normalized ``owner/name`` of the current checkout's ``origin`` remote, or
    ``None`` when there's no git remote."""
    try:
        remote = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            capture_output=True,
            text=True,
            check=True,
            cwd=cwd,
        ).stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None
    return normalize_repo_full_name(remote)


def git_toplevel(cwd: str | None = None) -> str | None:
    """Absolute path to the repository root, or ``None`` outside a git checkout."""
    try:
        return subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            check=True,
            cwd=cwd,
        ).stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


__all__ = ["detect_local_repo", "git_toplevel", "normalize_repo_full_name"]
