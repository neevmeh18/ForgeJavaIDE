from reforge_cli.cli import run

if __name__ == "__main__":
    raise SystemExit(run())
