"""Write the coding-agent MCP configuration that launches ``reforge-mcp``.

The project identifier is stamped into the server's ``REFORGE_PROJECT`` env so
matching does not depend on the agent's working directory. We write project-local
files: ``.mcp.json`` for Claude Code and ``.codex/config.toml`` for Codex.

Claude's JSON is merged (other MCP servers are preserved). Codex's TOML has no
stdlib writer, so we only create it when absent and otherwise print the block to add.
"""

import json
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path

MCP_SERVER_NAME = "reforge"
MCP_COMMAND = "reforge-mcp"


class Agent(StrEnum):
    CLAUDE = "claude"
    CODEX = "codex"


class ConfigOutcome(StrEnum):
    WRITTEN = "written"
    UPDATED = "updated"
    SKIPPED = "skipped"  # left an existing file untouched; manual step printed


@dataclass(frozen=True)
class AgentConfigResult:
    agent: Agent
    path: Path
    outcome: ConfigOutcome
    message: str


def _server_entry(project: str) -> dict:
    return {"command": MCP_COMMAND, "env": {"REFORGE_PROJECT": project}}


def write_claude_config(root: Path, project: str) -> AgentConfigResult:
    path = root / ".mcp.json"
    document: dict = {}
    updated = False
    if path.is_file():
        try:
            document = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(document, dict):
                raise ValueError
        except (json.JSONDecodeError, ValueError):
            return AgentConfigResult(
                Agent.CLAUDE,
                path,
                ConfigOutcome.SKIPPED,
                f"{path} exists but isn't valid JSON. Add the 'reforge' server manually.",
            )
        updated = True
    servers = document.setdefault("mcpServers", {})
    servers[MCP_SERVER_NAME] = _server_entry(project)
    path.write_text(json.dumps(document, indent=2) + "\n", encoding="utf-8")
    outcome = ConfigOutcome.UPDATED if updated else ConfigOutcome.WRITTEN
    message = f"Wrote Claude Code MCP config to {path}."
    return AgentConfigResult(Agent.CLAUDE, path, outcome, message)


def codex_config_block(project: str) -> str:
    return (
        f"[mcp_servers.{MCP_SERVER_NAME}]\n"
        f'command = "{MCP_COMMAND}"\n\n'
        f"[mcp_servers.{MCP_SERVER_NAME}.env]\n"
        f'REFORGE_PROJECT = "{project}"\n'
    )


def write_codex_config(root: Path, project: str) -> AgentConfigResult:
    path = root / ".codex" / "config.toml"
    if path.is_file():
        block = codex_config_block(project)
        message = f"{path} already exists. Add this block if it's missing:\n{block}"
        return AgentConfigResult(Agent.CODEX, path, ConfigOutcome.SKIPPED, message)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(codex_config_block(project), encoding="utf-8")
    message = f"Wrote Codex MCP config to {path}."
    return AgentConfigResult(Agent.CODEX, path, ConfigOutcome.WRITTEN, message)


def claude_config_present(root: Path) -> bool:
    path = root / ".mcp.json"
    if not path.is_file():
        return False
    try:
        document = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    return isinstance(document, dict) and MCP_SERVER_NAME in document.get("mcpServers", {})


def codex_config_present(root: Path) -> bool:
    path = root / ".codex" / "config.toml"
    try:
        return path.is_file() and MCP_SERVER_NAME in path.read_text(encoding="utf-8")
    except OSError:
        return False


__all__ = [
    "Agent",
    "AgentConfigResult",
    "ConfigOutcome",
    "claude_config_present",
    "codex_config_block",
    "codex_config_present",
    "write_claude_config",
    "write_codex_config",
]
