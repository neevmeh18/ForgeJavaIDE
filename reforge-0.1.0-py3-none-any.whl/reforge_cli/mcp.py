"""Stdio MCP server for ReForge prompt enhancement (`reforge-mcp`)."""

import os
from collections.abc import Awaitable, Callable
from typing import Any

from mcp.server import MCPServer
from mcp.types import CallToolResult, TextContent

from reforge_cli.config import ClientConfig, ClientConfigError, load_client_config
from reforge_cli.git_remote import detect_local_repo
from reforge_cli.http import ClientRequestError, post_json_async
from reforge_cli.link import LinkError, load_link

INSTRUCTIONS = (
    "Call reforge_enhance_prompt before implementing code. Pass the developer's request "
    "**verbatim** as `prompt` — the user's own words, exactly as they wrote them, with no "
    "rewriting, summarizing, translating, or reformatting. Then use the returned enhanced prompt "
    "as task guidance while preserving that original request. The project is taken from "
    "REFORGE_PROJECT, the repository's .reforge/project.toml link, or the Git remote, and must "
    "already be registered and ingested in the ReForge dashboard."
)

PostJson = Callable[[ClientConfig, str, dict[str, Any]], Awaitable[dict[str, Any]]]


def _resolve_project(repo: str | None) -> str | None:
    """Precedence: explicit tool arg → REFORGE_PROJECT (stamped by `reforge init`)
    → the checkout's .reforge/project.toml link → the local Git remote."""
    if repo:
        return repo
    stamped = os.environ.get("REFORGE_PROJECT") or os.environ.get("REFORGE_REPO")
    if stamped:
        return stamped
    try:
        link = load_link()
    except LinkError:
        link = None
    if link:
        return link.project
    return detect_local_repo()


def _ok(body: dict[str, Any]) -> CallToolResult:
    enhanced_prompt = body.get("enhanced_prompt")
    if not isinstance(enhanced_prompt, str):
        return _error("invalid_response", "ReForge API response has no enhanced prompt.")
    return CallToolResult(
        content=[TextContent(type="text", text=enhanced_prompt)],
        # The product API response contains persistence metadata and guidance
        # provenance intended for the dashboard. Agents receive only the
        # rendered Markdown prompt, never the raw response object.
        structuredContent=None,
        isError=False,
    )


def _error(code: str, message: str) -> CallToolResult:
    return CallToolResult(
        content=[TextContent(type="text", text=message)],
        isError=True,
    )


def create_mcp(
    *, config: ClientConfig | None = None, post: PostJson = post_json_async
) -> MCPServer:
    mcp = MCPServer("reforge", version="0.4.0", instructions=INSTRUCTIONS)

    @mcp.tool(
        name="reforge_enhance_prompt",
        description=(
            "Enhance a coding prompt with the repository's ReForge security guidance. Pass the "
            "user's original request verbatim as `prompt` (their exact words — do not rewrite, "
            "summarize, or paraphrase it); ReForge stores it and returns a security-hardened "
            "version to follow."
        ),
    )
    async def enhance_prompt(
        prompt: str, repo: str | None = None, branch: str = "main"
    ) -> CallToolResult:
        resolved = _resolve_project(repo)
        if not resolved:
            return _error(
                "project_not_detected",
                "Could not detect a ReForge project. Run `reforge init` in this repository, "
                "or pass repo as owner/name.",
            )
        try:
            client_config = config or load_client_config()
            body = await post(
                client_config,
                "/v1/enhance",
                {"prompt": prompt, "repo": resolved, "branch": branch},
            )
        except ClientConfigError as exc:
            return _error("client_not_configured", str(exc))
        except ClientRequestError as exc:
            return _error("api_request_failed", str(exc))
        except Exception:
            return _error("client_error", "Unexpected ReForge client error.")
        return _ok(body)

    return mcp


def run() -> None:
    create_mcp().run(transport="stdio")


if __name__ == "__main__":
    run()
