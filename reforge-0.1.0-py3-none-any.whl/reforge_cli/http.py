"""Authenticated JSON requests to the ReForge API."""

from typing import Any

import httpx

from reforge_cli.config import ClientConfig

_USER_AGENT = "reforge-cli/0.1.0"


class ClientRequestError(RuntimeError):
    """A ReForge API request failed with a user-safe message.

    ``code`` carries the backend error code (e.g. ``plan_required``) when present,
    so callers can distinguish a credit/plan block from a genuine failure.
    """

    def __init__(self, message: str, code: str | None = None) -> None:
        super().__init__(message)
        self.code = code


# Credit/plan blocks — a real denial, not an operational failure.
CREDIT_BLOCK_CODES = frozenset(
    {"plan_required", "credit_limit_exceeded", "key_credit_limit_exceeded"}
)


def _message(response: httpx.Response) -> str:
    try:
        body = response.json()
    except ValueError:
        return response.text.strip() or f"HTTP {response.status_code}"
    if isinstance(body, dict):
        return str(body.get("message") or body.get("detail") or f"HTTP {response.status_code}")
    return f"HTTP {response.status_code}"


def _code(response: httpx.Response) -> str | None:
    try:
        body = response.json()
    except ValueError:
        return None
    return body.get("code") if isinstance(body, dict) else None


def _parse(response: httpx.Response) -> Any:
    if response.is_error:
        raise ClientRequestError(_message(response), _code(response))
    try:
        return response.json()
    except ValueError as exc:
        raise ClientRequestError("ReForge API returned an invalid JSON response.") from exc


def _as_dict(body: Any) -> dict[str, Any]:
    if not isinstance(body, dict):
        raise ClientRequestError("ReForge API returned an unexpected response.")
    return body


def _headers(config: ClientConfig) -> dict[str, str]:
    return {"X-API-Key": config.api_key, "User-Agent": _USER_AGENT}


def _url(config: ClientConfig, path: str) -> str:
    return f"{config.api_base_url}/{path.lstrip('/')}"


def get_json(config: ClientConfig, path: str, *, timeout: float = 30.0) -> Any:
    try:
        response = httpx.get(_url(config, path), headers=_headers(config), timeout=timeout)
    except httpx.HTTPError as exc:
        raise ClientRequestError(f"Could not reach the ReForge API: {exc}") from exc
    return _parse(response)


def post_json(
    config: ClientConfig, path: str, payload: dict[str, Any], *, timeout: float = 120.0
) -> dict[str, Any]:
    try:
        response = httpx.post(
            _url(config, path), json=payload, headers=_headers(config), timeout=timeout
        )
    except httpx.HTTPError as exc:
        raise ClientRequestError(f"Could not reach the ReForge API: {exc}") from exc
    return _as_dict(_parse(response))


async def post_json_async(
    config: ClientConfig, path: str, payload: dict[str, Any], *, timeout: float = 120.0
) -> dict[str, Any]:
    try:
        async with httpx.AsyncClient(timeout=timeout) as http:
            response = await http.post(
                _url(config, path), json=payload, headers=_headers(config)
            )
    except httpx.HTTPError as exc:
        raise ClientRequestError(f"Could not reach the ReForge API: {exc}") from exc
    return _as_dict(_parse(response))
